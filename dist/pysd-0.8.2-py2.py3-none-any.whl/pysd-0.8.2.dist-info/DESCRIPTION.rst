Project Documentation: http://pysd.readthedocs.org/


